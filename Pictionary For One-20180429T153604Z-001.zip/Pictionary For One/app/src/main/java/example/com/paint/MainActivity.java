package example.com.paint;

import android.graphics.Bitmap;
import android.net.http.HttpResponseCache;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

import org.json.JSONObject;
import org.json.JSONArray;

import javax.net.ssl.HttpsURLConnection;


public class MainActivity extends AppCompatActivity {

    private PaintView paintView;

    private Bitmap drawingMap;

    private static final String TARGET_URL = "https://vision.googleapis.com/v1/images:annotate?";
    private static final String API_KEY = "key=AIzaSyAXAWOscEv1QPQuwB_OLgzM6eXVskg1bJo";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        paintView = (PaintView) findViewById(R.id.paintView);
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        paintView.init(metrics);
    }
    public void normalButton(View v) {
        ImageButton button = (ImageButton) v;
        paintView.normal();
    }
    public void clearButton(View v) {
        ImageButton button = (ImageButton) v;
        paintView.clear();
    }

    public void eraseButton(View v) {
        ImageButton button = (ImageButton) v;
        paintView.erase();
    }
    public void doneButton(View v) throws IOException {
        Button button = (Button) v;
        TextView text = findViewById(R.id.textView);
        paintView.setDrawingCacheEnabled(true);
        paintView.invalidate();
        OutputStream pic = null;
        drawingMap = paintView.getDrawingCache();

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        drawingMap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] imageData = stream.toByteArray();
        String encodedImage = android.util.Base64.encodeToString(imageData, android.util.Base64.DEFAULT);

        URL serverUrl = new URL(TARGET_URL + API_KEY);
        URLConnection urlConnection = serverUrl.openConnection();
        HttpURLConnection httpConnection = (HttpURLConnection) urlConnection;
        httpConnection.setRequestMethod("POST");
        httpConnection.setRequestProperty("Content-Type", "application/json");
        httpConnection.setDoOutput(true);
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
        BufferedWriter httpRequestBodyWriter = new BufferedWriter(new
                OutputStreamWriter(httpConnection.getOutputStream()));
        httpRequestBodyWriter.write
                ("{\"requests\":[{\"image\":{\"content\":\"" + encodedImage +
                        "\"},\"features\":[{\"type\":\"LABEL_DETECTION\",\"maxResults\":30}]}]}");
        httpRequestBodyWriter.close();
        String response = httpConnection.getResponseMessage();
        if (httpConnection.getInputStream() == null) {
            System.out.println("No stream");
            return;
        }

        Scanner httpResponseScanner = new Scanner (httpConnection.getInputStream());
        String resp = "";
        while (httpResponseScanner.hasNext()) {
            String line = httpResponseScanner.nextLine();
            resp += line;
            //  alternatively, print the line of response
        }
        Log.w("please", resp);
        httpResponseScanner.close();

    }
}
